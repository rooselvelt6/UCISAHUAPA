This module provides a mobile compliant interface for Odoo Community web.

Features:

 * New navigation with an App drawer
 * Keyboard shortcuts for easier navigation
 * Display kanban views for small screens if an action or field One2x
 * Set chatter side (Optional per user)
